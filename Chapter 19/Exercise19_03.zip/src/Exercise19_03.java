/*
Author: Luis Perez
Date: 03/20/24

Description: Generics Fundamental
 */
import java.util.ArrayList;

public class Exercise19_03 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(14);
        list.add(24);
        list.add(14);
        list.add(42);
        list.add(25);

        ArrayList<Integer> newList = removeDuplicates(list);

        System.out.print(newList);
    }

    private static <Thing> ArrayList<Thing> removeDuplicates(ArrayList<Thing> list){
            ArrayList<Thing> newList = new ArrayList<Thing>(list);
        for (int i = 0; i <= list.size(); i++) {
            for (int j = i +1; j < newList.size(); j++) {
                if (list.get(i) == newList.get(j)) {
                    newList.remove(j);
                    j--;

                }
            }
        }
        return newList;
    }

}
