import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.shape.Polygon;
import javafx.scene.text.Text;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        StackPane pane = new StackPane();
        Polygon octagon = new Polygon();
        octagon.setFill(Color.RED);
        octagon.setStroke(Color.WHITE);
        octagon.setStrokeWidth(10);
        pane.setBackground(Background.fill(Color.BLACK));

        double centerX, centerY, radius;
        centerX = 250;
        centerY = 250;
        radius = 200;

        ObservableList<Double> list = octagon.getPoints();

          for (int i = 0; i < 8; i++) {
              list.add(centerX + radius * Math.cos(2 * i * Math.PI / 8));
              list.add(centerY - radius * Math.sin(2 * i * Math.PI / 8));
          }
          Text stop = new Text("STOP");
          stop.setFont(Font.font("Times New Roman", 145));
          stop.setFill(Color.WHITE);
          octagon.setRotate(22.5);



          pane.getChildren().addAll(octagon,stop);

          Scene scene = new Scene(pane, 500, 500);
          stage.setTitle("Stop Sign");
          stage.setScene(scene);
          stage.show();


    }
}



