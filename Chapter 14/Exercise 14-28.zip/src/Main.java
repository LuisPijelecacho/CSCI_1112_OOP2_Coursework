import java.util.Random;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;


    public class Main extends Application {

        public static void main(String[] args) {
            launch(args);
        }

        @Override
        public void start(Stage primaryStage) {
            Random random = new Random();
            ClockPane clock = new ClockPane();
            clock.setHour(random.nextInt(12));
            clock.setMinute(random.nextInt(2) * 30);
            String timeString = clock.getHour() + ":" + clock.getMinute() + ":" + clock.getSecond();
            clock.setHourVis(true);
            clock.setMinuteVis(true);
            Label label = new Label(timeString);

            BorderPane pane = new BorderPane();
            pane.setCenter(clock);
            pane.setBottom(label);
            BorderPane.setAlignment(label, Pos.BOTTOM_CENTER);

            Scene scene = new Scene(pane, 600, 600);
            primaryStage.setScene(scene);
            primaryStage.show();
        }

    }
