import java.io.*;

public class Main {
    public static void main (String []args) throws IOException {
        input();
        sum();
    }
    public static void input() throws IOException {

        try (
            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream("Exercise17_3.dat"));
        ){
            for(int i = 0; i < 100; i++){
                dataOutputStream.writeInt((int) (Math.random() * 100));
                dataOutputStream.writeUTF(" ");
            }
        }
         catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    public static void sum() throws IOException{
        int total = 0;
        try (
            DataInputStream dataInputStream = new DataInputStream(new FileInputStream("Exercise17_3.dat"));
        ){

            while(true){
               total += dataInputStream.readInt();
            }

        } catch (EOFException e) {
            System.out.print(total);
        }
    }
}
