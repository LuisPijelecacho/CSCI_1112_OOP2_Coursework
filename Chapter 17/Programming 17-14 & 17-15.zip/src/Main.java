import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("What would you like to name the file: ");
        String fileName = scanner.next();

        File file = new File(fileName + ".txt");
        String writtenContents = "####";
        char[] toBeEncrypted = writtenContents.toCharArray();

        try (
                BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(file))
        ) {
            char x;
            for (int i = 0; i < writtenContents.length(); i++) {
                x = toBeEncrypted[i];
                char encrypt = (char) (x + 5);
                outputStream.write(encrypt);
            }
        }

        try(
                BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(file))
        ) {StringBuilder stringBuilder = new StringBuilder();
            int encryptedChar;
            while ((encryptedChar = inputStream.read()) != -1) {
                char decryptedChar = (char) (encryptedChar - 5);
                stringBuilder.append(decryptedChar);
            }
            System.out.println(stringBuilder.toString());
        }









    }

}