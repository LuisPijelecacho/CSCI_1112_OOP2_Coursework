public class Main {
    public static void main (String[]args){
        System.out.println(gcd(20, 300));
    }
    public static int gcd(int m, int n){
        if (m % n == 0){
            return n;
        } else {
            return gcd(n, m % n);
        }
    }
}
