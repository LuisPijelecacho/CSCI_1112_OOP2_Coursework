import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;

public class Main extends Application {
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        SierpinskiTrianglePane pane = new SierpinskiTrianglePane(); //recursive triangle pane
        Button plus = new Button("+");
        plus.setOnAction(e -> {
            if (pane.getOrder() == 0) {
                pane.setOrderPlus(pane.getOrder());
                pane.setOrderPlus(pane.getOrder() + 1);
            } else
                pane.setOrderPlus(pane.getOrder() + 1);
        });
        plus.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.UP && pane.getOrder() == 0){
                pane.setOrderPlus(pane.getOrder());
                pane.setOrderPlus(pane.getOrder() + 1);
            } else
                pane.setOrderPlus(pane.getOrder() + 1);
        });

        Button minus = new Button("-");
        minus.setOnAction(e -> {
            if (pane.getOrder() == 0) {
                pane.setOrderMinus(pane.getOrder());
            } else
                pane.setOrderMinus(pane.getOrder() - 1);
        });
        minus.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.DOWN && pane.getOrder() == 0){
                pane.setOrderMinus(pane.getOrder());
            } else
                pane.setOrderMinus(pane.getOrder() - 1);
        });
        plus.setAlignment(Pos.BOTTOM_LEFT);
        minus.setAlignment(Pos.BOTTOM_RIGHT);

        // Pane to hold label, text field, and a button hold label and text field
        HBox hBox = new HBox(10);
        hBox.getChildren().addAll(plus, minus);
        hBox.setAlignment(Pos.CENTER);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(pane);
        borderPane.setBottom(hBox);

        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 200, 210);
        primaryStage.setTitle("SierpinskiTriangle"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
        //listener for resizing
        pane.widthProperty().addListener(ov -> pane.paint());
        pane.heightProperty().addListener(ov -> pane.paint());
    }


    /**
     * Pane for displaying triangles
     */
     static class SierpinskiTrianglePane extends Pane {
        private static int order = 0;

        /**
         * Set a new order
         *
         */
        public int getOrder() {
            return order;
        }

        public void setOrderPlus(int order) {
            this.order = order;
            paint();
        }

        public void setOrderMinus(int order) {
            this.order = order;
            paint();
        }

        SierpinskiTrianglePane() {
        }

        protected void paint() {
            // Select three points in proportion to the pane size three initial points
            Point2D p1 = new Point2D(getWidth() / 2, 10);
            Point2D p2 = new Point2D(10, getHeight() - 10);
            Point2D p3 = new Point2D(getWidth() - 10, getHeight() - 10);
            this.getChildren().clear(); // Clear the pane before redisplay

            displayTriangles(order, p1, p2, p3); //draw a triangle
        }

        private void displayTriangles(int order, Point2D p1,
                                      Point2D p2, Point2D p3) {
            if (order == 0) {
                // Draw a triangle to connect three points create a triangle
                Polygon triangle = new Polygon();
                triangle.getPoints().addAll(p1.getX(), p1.getY(), p2.getX(),
                        p2.getY(), p3.getX(), p3.getY());
                triangle.setStroke(Color.BLACK);
                triangle.setFill(Color.WHITE);

                this.getChildren().add(triangle);
            } else {
                // Get the midpoint on each edge in the triangle
                Point2D p12 = p1.midpoint(p2);
                Point2D p23 = p2.midpoint(p3);
                Point2D p31 = p3.midpoint(p1);

                // Recursively display three triangles
                displayTriangles(order - 1, p1, p12, p31); //top subtriangle
                displayTriangles(order - 1, p12, p2, p23); //left subtriangle
                displayTriangles(order - 1, p31, p23, p3); //right subtriangle
            }
        }
    }
}
