public class RecursiveExercise {
    public static void main (String[]args){
        reverseDisplay("Exercise");
    }

    public static void reverseDisplay(String value)
    {
        if (value.isEmpty()){
        System.out.println(value);
    }
        else
        {
            System.out.print(value.charAt(value.length()-1));
            reverseDisplay(value.substring(0,value.length()-1));
        }
    }

}



