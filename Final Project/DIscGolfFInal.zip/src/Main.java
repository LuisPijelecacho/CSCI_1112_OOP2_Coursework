import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * @author luisperez
 *03/29/24
 */

public class Main extends Application {
    @Override
    public void start(Stage stage){
        BorderPane welcome = new BorderPane();
        welcome.setStyle("-fx-background-color: #8383e5");
        Label label = new Label("Let's Disc Golf!!!");
        label.setFont(Font.font("Times New Roman", FontWeight.BLACK, FontPosture.REGULAR, 35));
        label.setAlignment(Pos.CENTER);
        HBox paneForButtons = new HBox();

        Button newGameBt = new Button("New Game!");
        newGameBt.setStyle("-fx-background-color: #429191 ");
        newGameBt.setAlignment(Pos.BOTTOM_CENTER);
        newGameBt.setOnAction(e -> {
            NewGame.newGameFillOut();
            stage.getScene().setRoot(NewGame.pane);
            NewGame.pane.setStyle("-fx-background-color: #d76262");
            NewGame.pane.setStyle("-fx-border-color: #bb2834");
        });


        paneForButtons.setAlignment(Pos.CENTER);
        paneForButtons.setSpacing(15);
        paneForButtons.getChildren().addAll(newGameBt);



        welcome.setCenter(label);
        welcome.setBottom(paneForButtons);



        Scene scene = new Scene(welcome, 500, 500);
        stage.setScene(scene);
        stage.setTitle("Disc Golf");
        stage.show();


    }
    //This is to be called after the user has filled out the information inside the new game object,
    // it will show the simple UI of players, plus and minus score, hole number, next hole bt.



}
