import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;




public class Player {
    private  String name;
    private int score;

    public static HBox playersPane = new HBox(10);


    public Player(){

    }
    public Player(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setScore(int score){
        this.score = score;
    }

    public void incrementScore (){
       score++;
    }

    public void decreaseScore (){
        if(score>0){
            score--;
        }
    }


    public int getScores() {
        return score;
    }

    /**
     * @param player THis is an object that helps manage the players in the game, keep their scores etc.
     */
    public static void setPlayersPane(Player player){
        playersPane.setStyle("-fx-background-color: pink");
        Label playerNm = new Label(player.getName());
        Label scoreLabel = new Label(String.valueOf(player.getScores()));
        Button plusBT = new Button("+");
        System.out.println(player.getName());
        plusBT.setOnAction(e -> {
            player.incrementScore();
            scoreLabel.setText(String.valueOf(player.getScores()));


        });
        Button minusBT = new Button("-");
        minusBT.setOnAction(e -> {
            player.decreaseScore();
            scoreLabel.setText(String.valueOf(player.getScores()));
        });



        playersPane.setPadding(new Insets(15,15,15,15));
        playersPane.getChildren().addAll(new Label(player.getName()),plusBT,minusBT, scoreLabel);
        NewGame.pane.getChildren().clear();
        NewGame.pane.getChildren().addAll(playersPane);


    }

}
