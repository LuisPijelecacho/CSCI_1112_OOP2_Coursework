import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;

import java.util.ArrayList;

/**
 * The following class is to be able to create a new game as well as creating the pane to be used as the game progresses.
 */
public class NewGame {

    private static String nameOfCourse;
    private static int numberOfPlayers;
    public static ArrayList<Player> playersNames = new ArrayList<>();
    private static int holesInTheCourse;
    public static FlowPane pane = new FlowPane(Orientation.VERTICAL);

    public NewGame(){

    }

    public NewGame(String nameOfCourse, int numberOfPlayers, int holesInTheCourse){
        this.nameOfCourse = nameOfCourse;
        this.numberOfPlayers = numberOfPlayers;
        this.holesInTheCourse = holesInTheCourse;
    }

    public String getNameOfCourse() {
        return nameOfCourse;
    }

    public void setNameOfCourse(String nameOfCourse) {
        this.nameOfCourse = nameOfCourse;
    }

    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }

    public void setNumberOfPlayers(int numberOfPlayers) {
        this.numberOfPlayers = numberOfPlayers;
    }

    public ArrayList getPlayersNames() {
        return playersNames;
    }

    public void setPlayersNames(ArrayList playersNames) {
        this.playersNames = playersNames;
    }

    public int getHolesInTheCourse() {
        return holesInTheCourse;
    }

    public void setHolesInTheCourse(int holesInTheCourse) {
        this.holesInTheCourse = holesInTheCourse;
    }

    public Pane getRootPane(){
        return pane;
    }

    /**
     * THe following method created a UI to gather information from the user about the course, players and scores
     */
    public static void newGameFillOut(){
        pane.getChildren().clear();
        NewGame gameFill = new NewGame();
        pane.setPadding(new Insets(14, 14, 14, 14));
        pane.setHgap(5);
        pane.setVgap(5);



        Label nameOfCourseLB = new Label("Name of the Course: ");
        nameOfCourseLB.setStyle("-fx-background-color: #b4e0e8");
        TextField nameOfCourseTF = new TextField();
        Button nameCourseBT = new Button("Save");
        nameCourseBT.setOnAction(e ->{
            String nameOfCourseText = nameOfCourseTF.getText();
            if(nameOfCourseTF.toString().equalsIgnoreCase(null)){
                new Label("Please enter name of course");
            }
            else{
                gameFill.setNameOfCourse(nameOfCourseText);
                System.out.println(gameFill.getNameOfCourse());
            }
        });


        Label numberOfHolesLB = new Label("Number of holes: ");
        numberOfHolesLB.setStyle("-fx-background-color: #b4e0e8");
        TextField numberOfHolesTF = new TextField();
        Button numberOfHolesBT = new Button("Save");

        numberOfHolesBT.setOnAction(e -> {
            int numberOfHolesText = Integer.parseInt(numberOfHolesTF.getText());
            if (numberOfHolesTF.toString().equalsIgnoreCase(null)){
                new Label ("Please enter number of holes");
            }
            else{
                try {

                    gameFill.setHolesInTheCourse(numberOfHolesText);
                    System.out.println(gameFill.getHolesInTheCourse());
                } catch(NumberFormatException numb){
                    new Label ("Please input a valid digit.");
                }
            }
        });

        Label numberOfPlayersLB = new Label("Number of Players:");
        numberOfPlayersLB.setStyle("-fx-background-color: #b4e0e8");
        TextField numberOfPlayersTF = new TextField();
        Button numberOfPlayersBT = new Button("Save");
        numberOfPlayersBT.setOnAction( e -> {
            numberOfPlayers = (Integer.parseInt(numberOfPlayersTF.getText()));
        });


        Button addPlayerBT = new Button("Add Player Names");
        addPlayerBT.setOnAction(e -> {
            for (int i = 0; i < numberOfPlayers; i++){
            TextField playerTF = new TextField();
            Button saveBT = new Button("Save");
            saveBT.setOnAction(ep -> {
                Player player = new Player(playerTF.getText());
                player.setName(playerTF.getText());
                playersNames.add(player);
            });
            pane.getChildren().addAll(new Label("Player " + (i + 1) + " Name:"), playerTF, saveBT);

            }

        });

        Button gameOnBT = new Button("Let's Play!");
        gameOnBT.setOnAction( e -> {
            pane.getChildren().clear();
            for (int i = 0; i < numberOfPlayers; i++) {
                Player player = new Player(String.valueOf(playersNames.get(i).getName()));
                Player.setPlayersPane(player);

            }
            Button finish = new Button("Finish Game");
            finish.setAlignment(Pos.BOTTOM_RIGHT);
            finish.setOnAction(ep -> {
                NewGame.pane.getChildren().clear();
                Label thankYouLabel = new Label("Thank you for playing.");
                NewGame.pane.getChildren().add(thankYouLabel);

                for (int i = 0; i < NewGame.playersNames.size(); i++) {
                    Label playerLabel = new Label("Player: " + playersNames.get(i).getName() + " - Score: " + playersNames.get(i).getScores());
                    NewGame.pane.getChildren().add(playerLabel);
                }
            });
            pane.getChildren().add(finish);
        });



        pane.getChildren().addAll(nameOfCourseLB,nameOfCourseTF,nameCourseBT,numberOfHolesLB,numberOfHolesTF,numberOfHolesBT,
                numberOfPlayersLB,numberOfPlayersTF,numberOfPlayersBT, addPlayerBT, gameOnBT);

    }
}

