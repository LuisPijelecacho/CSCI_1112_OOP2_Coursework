import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;


public class Main extends Application {

    @Override
    public void start(Stage stage){
        Pane pane = new Pane();
        Rectangle rectangle = new Rectangle(50, 75);
        rectangle.setFill(Color.ORANGE);
        Polygon pentagon = new Polygon();
        pentagon.setFill(Color.BLACK);

        double centerX, centerY, radius;
        centerX = 250;
        centerY = 250;
        radius = 200;

        ObservableList<Double> list = pentagon.getPoints();

        for (int i = 0; i < 5; i++) {
            list.add(centerX + radius * Math.cos(2 * i * Math.PI / 5));
            list.add(centerY - radius * Math.sin(2 * i * Math.PI / 5));
        }
        pentagon.setRotate(55);

        pane.getChildren().add(pentagon);
        pane.getChildren().add(rectangle);

        PathTransition pT = new PathTransition();
        pT.setDuration(Duration.millis(10000));
        pT.setPath(pentagon);
        pT.setNode(rectangle);
        pT.setCycleCount(Timeline.INDEFINITE);
        pT.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        pT.play();

        FadeTransition fT = new FadeTransition();
        fT.setDuration(Duration.millis(5000));
        fT.setNode(rectangle);
        fT.setFromValue(1.0);
        fT.setToValue(0.1);
        fT.setCycleCount(Timeline.INDEFINITE);
        fT.play();

        pane.setOnMouseClicked(e -> {
            if (pT.getStatus() == Animation.Status.PAUSED){
                pT.play();
                fT.play();
            }
            else {
                pT.pause();
                fT.pause();
            }});

        Scene scene = new Scene(pane,500, 500);
        stage.setScene(scene);
        stage.show();


    }
}
