import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;

import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application {

    private static final String MEDIA_URL = "https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3";
    TextField textField = new TextField();
    Text countDown = new Text(textField.getText());
    Media media = new Media(MEDIA_URL);
    MediaPlayer mediaPlayer = new MediaPlayer(media);

    MediaView mediaView = new MediaView(mediaPlayer);


    Timeline timeline = new Timeline(
            new KeyFrame(Duration.seconds(1), e -> {
                int initialTime = Integer.parseInt(countDown.getText());
                countDown.setText(String.valueOf(initialTime - 1));
                System.out.println(initialTime);

                if (initialTime - 1 <= 0) {
                    stopAnimation();
                    //mediaPlayer.play();
                }
            })
    );

    @Override
    public void start(Stage stage){

        timeline.setCycleCount(Timeline.INDEFINITE);


        BorderPane borderPane = new BorderPane();
        HBox paneForTextField = new HBox(20);
        Text text = new Text("Set time: ");
        paneForTextField.getChildren().addAll(text,textField);

        StackPane pane = new StackPane();
        pane.getChildren().addAll(countDown,mediaView);
        borderPane.setCenter(pane);
        borderPane.setTop(paneForTextField);
        textField.setOnKeyPressed( e -> {
                countDown.setText(textField.getText());
                timeline.play();

        });

        mediaPlayer.setVolume(100);


        Scene scene = new Scene(borderPane, 200, 200);
        stage.setScene(scene);
        stage.show();

    }
    private void stopAnimation(){
        timeline.stop();
    }

    public static void main(String[] args){
        launch();
    }
}
