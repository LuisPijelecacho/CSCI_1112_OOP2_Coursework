import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;


public class Main extends Application {
    @Override
    public void start(Stage stage) {
        Pane pane = new Pane();
        Text text = new Text(100, 100,"Programming is fun");
        pane.getChildren().add(text);

        HBox paneForMovingButtons = new HBox(20);
        Button bL = new Button("Left");
        Button bR = new Button("Right");
        bL.setOnAction( e -> {
            if (!(text.getX() < 20)){
                text.setX(text.getX() - 5);
            }else text.setX(text.getX());
        });
        bR.setOnAction( e -> {
            if (!(text.getX() > 200)){
                text.setX(text.getX() + 5);
            }else text.setX(text.getX());
        });

        paneForMovingButtons.setPadding(new Insets(5,5,5,5));
        paneForMovingButtons.setAlignment(Pos.CENTER);
        paneForMovingButtons.getChildren().addAll(bL,bR);

        VBox paneForRadioButtons = new VBox(20);
        RadioButton green = new RadioButton("Green");
        RadioButton red = new RadioButton("Red");
        RadioButton blue = new RadioButton("Blue");
        paneForRadioButtons.setPadding(new Insets(5,5,5,5));
        paneForRadioButtons.setAlignment(Pos.CENTER);
        paneForRadioButtons.getChildren().addAll(green,red,blue);


        green.setOnAction(e -> text.setFill(Color.GREEN));
        red.setOnAction(e -> text.setFill(Color.RED));
        blue.setOnAction(e -> text.setFill(Color.BLUE));

        ToggleGroup group = new ToggleGroup();
        green.setToggleGroup(group);
        red.setToggleGroup(group);
        blue.setToggleGroup(group);

        BorderPane borderPane = new BorderPane();
        borderPane.setLeft(paneForRadioButtons);
        borderPane.setCenter(pane);
        borderPane.setBottom(paneForMovingButtons);

        Scene scene = new Scene(borderPane, 400, 200);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
}
